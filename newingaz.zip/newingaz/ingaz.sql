-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 12, 2020 at 01:11 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ingaz`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`name`) VALUES
('Business Card'),
('Flyer'),
('Notebook');

-- --------------------------------------------------------

--
-- Table structure for table `category_samples`
--

CREATE TABLE `category_samples` (
  `id` int(200) NOT NULL,
  `headline` varchar(250) DEFAULT NULL,
  `image` longblob DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `category_name` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `section` varchar(100) NOT NULL,
  `question` varchar(200) NOT NULL,
  `answer` varchar(400) NOT NULL,
  `access` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `section`, `question`, `answer`, `access`) VALUES
(1, 'General', 'Why was ingaz founded?', 'Ingaz was founded because there are no online printing services that deliver to all of Egypt.', 'internal'),
(15, 'Payment', 'Is there a cancel and refund policy?', 'Yes, but only if you cancel the order within 3 days.', 'internal'),
(16, 'Delivery', 'When is the order deliver?', 'Usually, within 7 days, if the order still isn\'t delivered, be sure to contact us.', 'internal'),
(17, 'General', 'Does INGAZ ship outside of Egypt?', 'No, INGAZ is an exclusively Eyptian Online Printing service.', 'internal');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(200) NOT NULL,
  `sender` varchar(250) NOT NULL,
  `receiver` varchar(250) NOT NULL,
  `receiver2` varchar(250) DEFAULT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `message` varchar(2500) DEFAULT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `sender`, `receiver`, `receiver2`, `subject`, `message`, `status`) VALUES
(1, 'internal', 'test', 'admin', 'Test Subject', 'Test Message', 0),
(2, 'internal', 'test2', 'admin', 'Test Subject2', 'Test Message2', 0),
(3, 'Ahmed', 'internal', 'admin', 'Test to internal', 'test to internal message', 0),
(5, 'Test', 'internal', 'admin', 'kkk', 'kkk', 0),
(6, 'test', 'internal', 'admin', 'aaa', 'aaa', 0),
(7, 'test', 'internal', 'admin', 'aaa', 'aaa', 0),
(8, 'test', 'internal', 'admin', 'This is the first test to send message', 'the message is from username = test', 0),
(9, 'test', 'internal', 'admin', 'This is the first test to send message', 'the message is from username = test', 0),
(10, 'test', 'internal', 'admin', '111', '111', 0),
(11, 'test', 'internal', 'admin', '111', '111', 0),
(12, 'test', 'internal', 'admin', '222', '222\r\n', 0),
(13, 'test', 'internal', 'admin', '222', '222\r\n', 0),
(14, 'test', 'internal', 'admin', '333', '333', 0),
(15, 'test', 'internal', 'admin', '444', '444', 0),
(16, 'internal', 'test', 'admin', 'aa', 'aa', 0),
(17, 'test', 'internal', 'admin', 'new', 'newww', 0),
(18, 'internal', 'test', 'admin', 'ahhhh', 'ahhhhh', 0),
(19, 'test', 'internal', 'admin', 'aa', 'aa', 0),
(20, 'internal', 'test', 'admin', 'not', 'not', 0),
(21, 'test', 'internal', 'admin', 'a', 'ddd', 0),
(22, 'internal', 'test', 'admin', 'ddd', 'a', 0),
(23, 'seiftest', 'internal', 'admin', 'seiftestmessage', 'messageseif', 0),
(24, 'internal', 'seiftest', 'admin', 'hii iam test seif', 'seif test', 0),
(25, 'seif@mail.com', 'internal', 'admin', 'orr', 'orr', 0),
(26, 'internal', 'seif@mail.com', 'admin', 'mashy', 'mashy', 0),
(27, 'test@mail.com', 'internal', 'admin', 'aaaaaaa', 'aaaaa', 0),
(28, 'test@mail.com', 'internal', 'admin', 'Hii TEST', 'TEST HIIII', 0),
(29, 'test@mail.com', 'internal', 'admin', 'TESSSSTTTT HIIIIIIII2', 'HIIIIIIIII TESTTTTTTTTTT 2', 0),
(30, 'internal', 'test@mail.com', 'admin', 'ok ya3am', 'mashy ya3am', 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` int(50) NOT NULL,
  `category` varchar(200) NOT NULL,
  `quantity` int(250) NOT NULL,
  `paper_quantity` int(11) NOT NULL,
  `papersize` varchar(200) NOT NULL,
  `design` longblob DEFAULT NULL,
  `printedsides` varchar(100) DEFAULT NULL,
  `finish` varchar(100) NOT NULL,
  `paperweight` varchar(500) NOT NULL,
  `description` varchar(2000) DEFAULT NULL,
  `cost` float DEFAULT NULL,
  `total_cost` float NOT NULL,
  `paper_cost` float DEFAULT NULL,
  `access` varchar(200) NOT NULL,
  `cart_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `delivery_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `order_status` int(11) NOT NULL DEFAULT 0,
  `approval` int(11) NOT NULL DEFAULT 0,
  `delivery_status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Triggers `order_details`
--
DELIMITER $$
CREATE TRIGGER `setCurrentDate` BEFORE INSERT ON `order_details` FOR EACH ROW SET new.cart_date = CURRENT_TIMESTAMP
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `setTotalCost` BEFORE INSERT ON `order_details` FOR EACH ROW SET new.total_cost = new.quantity * new.cost * 0.95
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`) VALUES
(1, 'test@mail.com', '180fb82a3517493b16f18a704e142ea55e864e269046bcb9e048181b5e4cde25d6a0025bb1bdf7430e94499e8826c28472e5');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(100) NOT NULL,
  `paper_type` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `price` double NOT NULL,
  `name_category` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `paper_type`, `description`, `price`, `name_category`) VALUES
(15, 'size', 'A4 (297 x 210 mm)', 0.16, 'Notebook'),
(16, 'size', 'A3 (420 x 297 mm)', 0.18, 'Notebook'),
(17, 'size', 'A2 (594 x 420 mm)', 0.2, 'Notebook'),
(18, 'size', 'Half Sheet (216 x 139.5 mm)', 5, 'Flyer'),
(19, 'size', 'Standard (279.5 x 216 mm)', 10, 'Flyer'),
(20, 'size', 'Large Format (432 x 279.5 mm)', 15, 'Flyer'),
(21, 'size', 'Standard (50.8 x 88.9 mm)', 0.5, 'Business Card'),
(31, 'finish', 'Matte', 0.1, 'Business Card'),
(32, 'finish', 'Matte', 1, 'Flyer'),
(34, 'finish', 'Gloss', 0.2, 'Business Card'),
(35, 'finish', 'Gloss', 2, 'Flyer'),
(37, 'finish', 'UV Gloss', 0.3, 'Business Card'),
(38, 'finish', 'UV Gloss', 3, 'Flyer'),
(40, 'weight', '135 gsm', 0.1, 'Business Card'),
(41, 'weight', '135 gsm', 0.1, 'Flyer'),
(42, 'weight', '135 gsm', 0.1, 'Notebook'),
(43, 'weight', '150 gsm', 0.2, 'Business Card'),
(44, 'weight', '150 gsm', 0.2, 'Flyer'),
(45, 'weight', '150 gsm', 0.2, 'Notebook'),
(46, 'weight', '170 gsm', 0.3, 'Business Card'),
(47, 'weight', '170 gsm', 0.3, 'Flyer'),
(48, 'weight', '170 gsm', 0.3, 'Notebook'),
(49, 'weight', '250 gsm', 0.4, 'Business Card'),
(50, 'weight', '250 gsm', 0.4, 'Flyer'),
(51, 'weight', '250 gsm', 0.4, 'Notebook'),
(52, 'weight', '300 gsm', 0.5, 'Business Card'),
(53, 'weight', '300 gsm', 0.5, 'Flyer'),
(54, 'weight', '300 gsm', 0.5, 'Notebook'),
(55, 'weight', '400 gsm', 0.6, 'Business Card'),
(56, 'weight', '400 gsm', 0.6, 'Flyer'),
(58, 'finish', 'Uncoated', 0, 'Business Card'),
(59, 'finish', 'Uncoated', 0.6, 'Flyer');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(200) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `Fname` char(100) NOT NULL,
  `Lname` char(100) NOT NULL,
  `address` varchar(20) DEFAULT NULL,
  `mobile` int(11) NOT NULL,
  `bday` date NOT NULL,
  `gender` char(7) DEFAULT NULL,
  `access` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`, `Fname`, `Lname`, `address`, `mobile`, `bday`, `gender`, `access`) VALUES
(1, 'admin@mail.com', 'admin', '3c9909afec25354d551dae21590bb26e38d53f2173b8d3dc3eee4c047e7ab1c1eb8b85103e3be7ba613b31bb5c9c36214dc9f14a42fd7a2fdb84856bca5c44c2', 'Admin', 'One', 'Madinet Nasr', 1234678915, '2020-06-06', 'male', 'admin'),
(2, 'internal@mail.com', 'internal', '3c9909afec25354d551dae21590bb26e38d53f2173b8d3dc3eee4c047e7ab1c1eb8b85103e3be7ba613b31bb5c9c36214dc9f14a42fd7a2fdb84856bca5c44c2', 'internal', 'One', 'Sheration', 1325639715, '2010-10-10', 'male', 'internal'),
(36, 'test@mail.com', 'test', '3c9909afec25354d551dae21590bb26e38d53f2173b8d3dc3eee4c047e7ab1c1eb8b85103e3be7ba613b31bb5c9c36214dc9f14a42fd7a2fdb84856bca5c44c2', 'Ahmed', 'One', 'New Nozha', 1142602024, '2010-10-10', 'male', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `category_samples`
--
ALTER TABLE `category_samples`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_name` (`category_name`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name_category` (`name_category`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category_samples`
--
ALTER TABLE `category_samples`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=70;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `category_samples`
--
ALTER TABLE `category_samples`
  ADD CONSTRAINT `category_samples_ibfk_1` FOREIGN KEY (`category_name`) REFERENCES `category` (`name`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`name_category`) REFERENCES `category` (`name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
