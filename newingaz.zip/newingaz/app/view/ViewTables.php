<?php
require_once("View.php");
class ViewTable extends View
{
    // public function editviewtable()
    // {
    //     $str = "";        
    //     foreach($this->model->getproducts() as $product){
    //         $str =  '<tr>'; 
    //         $str .= '<td>' . $product->getid()               ."</td>";
    //         $str .= '<td>' . $product->getpaper_type()       ."</td>";
    //         $str .= '<td>' . $product->getdescription()      ."</td>";
    //         $str .= '<td>' . $product->getprice()            ."</td>";
    //         $str .= '<td>' . $product->getname_category()    ."</td>";
    //         $str .= '<td><a href="editcourse.php?id='.$product->getid().'">Edit Course </a></td> ';
    //         $str .= '</tr>';
    //     }
    //     return $str;
    // }
}?>